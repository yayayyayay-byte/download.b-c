// dev mode idea
// js file for devmode.html
// this is just for testing purposes
// do not include in production builds

// import necessary variables and functions from main.js and ui.js
import { score, scoreSpan, pointsPerClick, pointsPerClickSpan, upgradeCost, upgradeCostSpan, farmCount, farmCountSpan, farmCost, farmCostSpan, farmCash, farmTimer, farmInterval, autoClickerCount, autoClickerCost, autoClickerIntervalId } from '../main.js';
import { showNotification } from '../ui.js';

// add a reset button for testing
document.getElementById('reset-game-btn').addEventListener('click', () => {
  score = 0;
  pointsPerClick = 1;
  upgradeCost = 10;
  farmCount = 0;
  farmCost = 50;
  farmCash = 0;
  farmTimer = farmInterval;
  autoClickerCount = 0;
  autoClickerCost = 100;
  autoClickerIntervalId.forEach(id => clearInterval(id));
  autoClickerIntervalId = [];
  scoreSpan.textContent = score;
  pointsPerClickSpan.textContent = pointsPerClick;
  upgradeCostSpan.textContent = upgradeCost;
  farmCountSpan.textContent = farmCount;
  farmCostSpan.textContent = farmCost;
  document.getElementById('autoclicker-count').textContent = autoClickerCount;
  document.getElementById('auto-clicker-cost').textContent = autoClickerCost;
  showNotification("Game has been reset!");
});

// add event listeners for buttons to test functionality 
document.getElementById('add-score-btn').addEventListener('click', () => {
  score += 100;
  scoreSpan.textContent = score;
  showNotification("Added 100 points to score");
});

document.getElementById('add-points-per-click-btn').addEventListener('click', () => {
  pointsPerClick += 1;
  pointsPerClickSpan.textContent = pointsPerClick;
  showNotification("Increased points per click by 1");
});

document.getElementById('add-upgrade-cost-btn').addEventListener('click', () => {
  upgradeCost += 10;
  upgradeCostSpan.textContent = upgradeCost;
  showNotification("Increased upgrade cost by 10");
});

document.getElementById('add-farm-btn').addEventListener('click', () => {
  farmCount += 1;
  farmCountSpan.textContent = farmCount;
  showNotification("Added 1 farm");
});

document.getElementById('add-farm-cost-btn').addEventListener('click', () => {
  farmCost += 10;
  farmCostSpan.textContent = farmCost;
  showNotification("Increased farm cost by 10");
});

document.getElementById('add-farm-cash-btn').addEventListener('click', () => {
  farmCash += 50;
  showNotification("Added 50 cash to farms");
});

document.getElementById('add-auto-clicker-btn').addEventListener('click', () => {
  autoClickerCount += 1;
  document.getElementById('autoclicker-count').textContent = autoClickerCount;
  showNotification("Added 1 autoclicker");
});
// add a text box that gives you a custom amount of score
document.getElementById('custom-score-btn').addEventListener('click', () => {
  const customScoreInput = document.getElementById('custom-score-input');
  const customScore = parseInt(customScoreInput.value);
  if (!isNaN(customScore)) {
    score += customScore;
    scoreSpan.textContent = score;
    showNotification(`Added ${customScore} points to score`);
  } else {
    showNotification("Invalid input for custom score");
  }
  customScoreInput.value = "";
});
showNotification("Dev mode loaded. Use the buttons to test functionality.");
//save on exit
window.addEventListener('beforeunload', () => {
  if (typeof saveGame === "function") saveGame();
});
// end of dev mode idea


// devmode.html starts her
// devmode.html is a special testing page that includes all game features for easy testing
// do not include in production builds
// use the .js file for devmode.html to add functionality
// this is just for testing purposes
// start of devmode.html

//end of devmode.html

// dmtest.js starts here
// dm test script for clicker-game-1
// This script is for testing purposes only and should not be included in production builds.
// this is just to test dark mode and other features
// no codes this is dmtest.js
// add a counter for my points for dev mode
// js file for dmtest.html
import { score, scoreSpan, farmCount, farmCountSpan, autoClickerCount } from '../main.js';
import { showNotification } from '../ui.js';


// this doesnt work :(

// ascensions dont save
// why not
// prob because savegame is in main.js
// import { saveGame } from '../main.js';
// import { loadGame } from '../main.js';
// import { saveGame, loadGame } from '../main.js';
// import { saveGame } from '../main.js';
// import { loadGame } from '../main.js';
// can you give me the ascension code again