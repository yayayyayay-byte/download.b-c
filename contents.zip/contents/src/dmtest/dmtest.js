// dm test script for clicker-game-1
// This script is for testing purposes only and should not be included in production builds.
// this is just to test dark mode and other features
// no codes this is dmtest.js
// js file for dmtest.html
import { score, scoreSpan, farmCount, farmCountSpan, autoClickerCount } from '../main.js';
import { showNotification } from '../ui.js';

// Codes data
const codes = {
  "CHATGPT": { reward: 1, claimed: false },
    "DALLE": { reward: 1, claimed: false },
    "MIDJOURNEY": { reward: 1, claimed: false },
    "STABLEDIFFUSION": { reward: 1, claimed: false },
    "BARD": { reward: 1, claimed: false },
    "CLAIMALLCODES": { reward: 1, claimed: false },
    "ILOVEJOKING": { reward: 1, claimed: false },
}
    // add dark mode feature
    // on dark mode click button,
    
    document.getElementById('dark-mode-btn').addEventListener('click', () => {
      document.body.classList.toggle('dark-mode');
      if (document.body.classList.contains('dark-mode')) {
        showNotification("Dark mode enabled");
      } else {
        showNotification("Dark mode disabled");
      }
    });
    // add light mode feature
    document.getElementById('light-mode-btn').addEventListener('click', () => {
      document.body.classList.remove('dark-mode');
      showNotification("Light mode enabled");
    });
    // add toggle button for dark mode and light mode
    document.getElementById('toggle-mode-btn').addEventListener('click', () => {
      document.body.classList.toggle('dark-mode');
      if (document.body.classList.contains('dark-mode')) {
        showNotification("Dark mode enabled");
      } else {
        showNotification("Light mode enabled");
      }
    });
    // add reset button for dark mode and light mode
    document.getElementById('reset-mode-btn').addEventListener('click', () => {
      document.body.classList.remove('dark-mode');
      showNotification("Mode reset to light mode");
    });
