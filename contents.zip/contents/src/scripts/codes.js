function showNotification(message, duration = 2000) {
  let notif = document.createElement('div');
  notif.className = 'notification';
  notif.textContent = message;
  document.body.appendChild(notif);
  setTimeout(() => {
    notif.remove();
  }, duration);
}

const codes = {
  "FREE100": { reward: 100, claimed: false },
  "FARMS4U": { reward: "farm", claimed: false },
  "AUTOBOOST": { reward: "autoclicker", claimed: false },
    "VVICTEST1": { reward: 100000, claimed: false},
    "VVICTEST2": { reward: -100000, claimed: false},
    "RESETME": { reward: -score, claimed: false }, // Example of a reset code
    "BOOSTME": { reward: "farm", claimed: false },
    "BOOSTME2": { reward: 100, claimed: false },
    "UNCLAIMABLE": { reward: 10000000, claimed: true }, // Example of an unclaimable code
    "MAN THIS AI SUCKS": { reward: 1, claimed: false },
    "MAN THIS AI REALLY SUCKS": { reward: 1, claimed: false },
    "MAN THIS AI HAS A GOOD SENSE OF HUMOR -- VIC :)": { reward: 1, claimed: false },
   "FREECODES": { reward: 1, claimed: false },
   "GOODAICODES": { reward: 50, claimed: false },
    "CHATGPT": { reward: 1, claimed: false },
    "DALLE": { reward: 1, claimed: false },
    "MIDJOURNEY": { reward: 1, claimed: false },
    "STABLEDIFFUSION": { reward: 20, claimed: false },
    "BARD": { reward: 1, claimed: false },
    "CLAIMALLCODES": { reward: 1, claimed: false },
    "ILOVEJOKING": { reward: 1, claimed: false },
    "MAN THIS AI SUCKS A WHOLE FRICKING LOT": { reward: 1, claimed: false },
    "AM I MEANT TO BE A PROGRAMMER": { reward: 1, claimed: false },
    "I HATE BUGS": { reward: 1, claimed: false },
    "DEBUGGING IS THE WORST": { reward: 30, claimed: false },
    "SO MUCH CODES": { reward: 1, claimed: false },
    "6": { reward: 6, claimed: false },
    "7": { reward: 7, claimed: false },
    "67": { reward: 67, claimed: false },
    "CHASESAYS67": { reward: -67, claimed: false },
    "ILOVE67": { reward: 67, claimed: false },
    "CHATGPTDALEWROTEALLTHESECODES": { reward: 1, claimed: false },
    "FREEPOINTS": { reward: 1000, claimed: false },
    "EXTRAPOINTS": { reward: 500, claimed: false },
    "MOREPOINTS": { reward: 250, claimed: false },
    "POINTSPOINTSPOINTS": { reward: 100, claimed: false },
    "CODESCODESCODES": { reward: 50, claimed: false },
    "ILOVECODES": { reward: 25, claimed: false },
    "RESET": { reward: "reset", claimed: false },
    "MUSTARD": { reward: "20 Farms", claimed: false },
    "V1XX,20382721973173298213": { reward: "1000 AUTOCLICKERS", claimed: false },
    "V1XX,20382721973173298214": { reward: "100000000000000 AUTOCLICKERS", claimed: false },
    "V1XX,20382721973173298215": { reward: "TOO MANY FARMS", claimed: false },
    "V1XX,20382721973173298216": { reward: "TOO MUCH AUTOCLICKERS", claimed: false },
};

function claimCode(code) {
  const entry = codes[code.toUpperCase()];
  if (!entry) {
    showNotification("Invalid code!");
    return;
  }
  if (entry.claimed) {
    showNotification("Code already claimed!");
    return;
  }
  if (typeof entry.reward === "number") {
    score += entry.reward;
    scoreSpan.textContent = score;
    showNotification(`You received ${entry.reward} points!`);
  } else if (entry.reward === "farm") {
    farmCount += 1;
    farmCountSpan.textContent = farmCount;
    showNotification("You received 1 farm!");
  } else if (entry.reward === "autoclicker") {
    autoClickerCount += 1;
    document.getElementById('autoclicker-count').textContent = autoClickerCount;
    showNotification("You received 1 autoclicker!");
  } else if (entry.reward === "reset") {
    score = 0;
    pointsPerClick = 1;
    upgradeCost = 10;
    farmCount = 0;
    farmCost = 50;
    farmCash = 0;
    farmTimer = farmInterval;
    autoClickerCount = 0;
    autoClickerCost = 100;
    autoClickerIntervalId.forEach(id => clearInterval(id));
    autoClickerIntervalId = [];
    scoreSpan.textContent = score;
    pointsPerClickSpan.textContent = pointsPerClick;
    upgradeCostSpan.textContent = upgradeCost;
    farmCountSpan.textContent = farmCount;
    farmCostSpan.textContent = farmCost;
    document.getElementById('autoclicker-count').textContent = autoClickerCount;
    document.getElementById('auto-clicker-cost').textContent = autoClickerCost;
    showNotification("Game has been reset!");
  } else if (entry.reward === "20 Farms") {
    farmCount += 20;
    farmCountSpan.textContent = farmCount;
    showNotification("You received 20 farms!");
  } else if (entry.reward === "1000 AUTOCLICKERS") {
    autoClickerCount += 1000;
    document.getElementById('autoclicker-count').textContent = autoClickerCount;
    showNotification("You received 1000 autoclickers!");
  } else if (entry.reward === "100000000000000 AUTOCLICKERS") {
    autoClickerCount += 100000000000000;
    document.getElementById('autoclicker-count').textContent = autoClickerCount;
    showNotification("You received 100000000000000 autoclickers!");
  } else if (entry.reward === "TOO MANY FARMS") {
    farmCount += 1e+30; // Arbitrary large number
    farmCountSpan.textContent = farmCount;
    showNotification("You received TOO MANY FARMS!");
  } else if (entry.reward === "TOO MUCH AUTOCLICKERS") {
    autoClickerCount += 1e+30; // Arbitrary large number
    document.getElementById('autoclicker-count').textContent = autoClickerCount;
    showNotification("You received TOO MUCH AUTOCLICKERS!");
  }
  entry.claimed = true;
  if (typeof saveGame === "function") saveGame();
}

document.getElementById('redeem-code-btn').addEventListener('click', () => {
  const codeInput = document.getElementById('code-input');
  claimCode(codeInput.value);
  codeInput.value = "";
});