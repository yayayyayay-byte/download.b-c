let score = 0;
let pointsPerClick = 1;
let upgradeCost = 10;

// Farms
let farmCount = 0;
let farmCost = 50;
let farmInterval = 10;
let farmReward = 10;
let farmCash = 0;
let farmTimer = farmInterval;

// Autoclickers
let autoClickerCount = 0;
let autoClickerCost = 100;
let autoClickerPower = 1;
let autoClickerUpgradeCost = 200;

// UI elements
const scoreSpan = document.getElementById('score');
const clickBtn = document.getElementById('click-btn');
const upgradeBtn = document.getElementById('upgrade-btn');
const upgradeCostSpan = document.getElementById('upgrade-cost');

const buyFarmBtn = document.getElementById('buy-farm-btn');
const farmCostSpan = document.getElementById('farm-cost');
const farmCountSpan = document.getElementById('farm-count');
const collectFarmsBtn = document.getElementById('collect-farms-btn');
const farmTimeSpan = document.getElementById('farm-time');

const autoClickerBtn = document.getElementById('buy-autoclicker-btn');
const autoClickerCostSpan = document.getElementById('autoclicker-cost');
const autoClickerCountSpan = document.getElementById('autoclicker-count');

// Dynamically add autoclicker upgrade button
const autoClickerUpgradeBtn = document.createElement('button');
autoClickerUpgradeBtn.id = 'upgrade-autoclicker-btn';
autoClickerUpgradeBtn.innerHTML = `Upgrade Autoclicker (+1 per autoclick) - Cost: <span id="autoclicker-upgrade-cost">${autoClickerUpgradeCost}</span>`;
autoClickerBtn.parentNode.insertBefore(autoClickerUpgradeBtn, autoClickerBtn.nextSibling);
const autoClickerUpgradeCostSpan = autoClickerUpgradeBtn.querySelector('#autoclicker-upgrade-cost');

// Save/load all game data
function saveGame() {
  localStorage.setItem('clickerGameSave', JSON.stringify({
    score,
    pointsPerClick,
    upgradeCost,
    farmCount,
    farmCost,
    farmCash,
    farmTimer,
    autoClickerCount,
    autoClickerCost,
    autoClickerPower,
    autoClickerUpgradeCost
  }));
}

function loadGame() {
  const saved = JSON.parse(localStorage.getItem('clickerGameSave') || '{}');
  score = saved.score ?? 0;
  pointsPerClick = saved.pointsPerClick ?? 1;
  upgradeCost = saved.upgradeCost ?? 10;
  farmCount = saved.farmCount ?? 0;
  farmCost = saved.farmCost ?? 50;
  farmCash = saved.farmCash ?? 0;
  farmTimer = saved.farmTimer ?? farmInterval;
  autoClickerCount = saved.autoClickerCount ?? 0;
  autoClickerCost = saved.autoClickerCost ?? 100;
  autoClickerPower = saved.autoClickerPower ?? 1;
  autoClickerUpgradeCost = saved.autoClickerUpgradeCost ?? 200;
}

// Game logic
clickBtn.addEventListener('click', () => {
  score += pointsPerClick;
  scoreSpan.textContent = score;
  saveGame();
});

upgradeBtn.addEventListener('click', () => {
  if (score >= upgradeCost) {
    score -= upgradeCost;
    pointsPerClick += 1;
    upgradeCost = Math.floor(upgradeCost * 1.5);
    scoreSpan.textContent = score;
    upgradeCostSpan.textContent = upgradeCost;
    saveGame();
  }
});

buyFarmBtn.addEventListener('click', () => {
  if (score >= farmCost) {
    score -= farmCost;
    farmCount += 1;
    farmCost = Math.floor(farmCost * 1.7);
    scoreSpan.textContent = score;
    farmCountSpan.textContent = farmCount;
    farmCostSpan.textContent = farmCost;
    saveGame();
  }
});

collectFarmsBtn.addEventListener('click', () => {
  if (farmCash > 0) {
    score += farmCash;
    farmCash = 0;
    scoreSpan.textContent = score;
    collectFarmsBtn.disabled = true;
    collectFarmsBtn.textContent = "Collect Farms";
    saveGame();
  }
});

// Farm cash generation
setInterval(() => {
  if (farmCount > 0) {
    farmTimer -= 1;
    farmTimeSpan.textContent = farmTimer;
    if (farmTimer <= 0) {
      farmCash += farmCount * farmReward;
      farmTimer = farmInterval;
      collectFarmsBtn.disabled = false;
      collectFarmsBtn.textContent = `Collect Farms (+${farmCash})`;
      saveGame();
    }
  } else {
    farmTimeSpan.textContent = farmInterval;
    farmTimer = farmInterval;
    collectFarmsBtn.disabled = true;
    collectFarmsBtn.textContent = "Collect Farms";
    farmCash = 0;
    saveGame();
  }
}, 1000);

// Autoclicker logic
autoClickerBtn.addEventListener('click', () => {
  if (score >= autoClickerCost) {
    score -= autoClickerCost;
    autoClickerCount += 1;
    autoClickerCost = Math.floor(autoClickerCost * 1.5);
    scoreSpan.textContent = score;
    autoClickerCostSpan.textContent = autoClickerCost;
    autoClickerCountSpan.textContent = autoClickerCount;
    saveGame();
  }
});

autoClickerUpgradeBtn.addEventListener('click', () => {
  if (score >= autoClickerUpgradeCost) {
    score -= autoClickerUpgradeCost;
    autoClickerPower += 1;
    autoClickerUpgradeCost = Math.floor(autoClickerUpgradeCost * 2);
    scoreSpan.textContent = score;
    autoClickerUpgradeCostSpan.textContent = autoClickerUpgradeCost;
    saveGame();
  }
});

// Autoclicker interval
setInterval(() => {
  if (autoClickerCount > 0) {
    score += autoClickerCount * autoClickerPower;
    scoreSpan.textContent = score;
    saveGame();
  }
}, 1000);

// Initialize UI
loadGame();
scoreSpan.textContent = score;
upgradeCostSpan.textContent = upgradeCost;
farmCostSpan.textContent = farmCost;
farmCountSpan.textContent = farmCount;
farmTimeSpan.textContent = farmTimer;
collectFarmsBtn.disabled = farmCash === 0;
collectFarmsBtn.textContent = farmCash > 0 ? `Collect Farms (+${farmCash})` : "Collect Farms";
autoClickerCostSpan.textContent = autoClickerCost;
autoClickerCountSpan.textContent = autoClickerCount;
autoClickerUpgradeCostSpan.textContent = autoClickerUpgradeCost;

// still doesnt save ascensions
//maybe its because its saving itself before the ascension save function can run



// my ascensions dont save
let ascensionCount = 0;
let ascensionRequirement = 100; // Initial requirement
const ascendBtn = document.getElementById('ascend-btn');

ascendBtn.addEventListener('click', () => {
  if (score >= ascensionRequirement) {
    score = 0;
    scoreSpan.textContent = score;
    farmCount = 0;
    farmCountSpan.textContent = farmCount;
    autoClickerCount = 0;
    document.getElementById('autoclicker-count').textContent = autoClickerCount;
    ascensionCount += 1;
    document.getElementById('ascension-count').textContent = ascensionCount;
    ascensionRequirement = Math.floor(ascensionRequirement * 1.5); // Increase requirement by 50%
    ascendBtn.textContent = `Ascend (Reset for bonus) - Requires ${ascensionRequirement} score`;
    pointsPerClick = 1 + ascensionCount;    // Increase click power
    upgradeCost = 10;
    upgradeCostSpan.textContent = upgradeCost;
    farmCost = 50;
    farmCostSpan.textContent = farmCost;
    farmCash = 0;
    farmTimer = farmInterval;
    autoClickerCost = 100;
    document.getElementById('autoclicker-cost').textContent = autoClickerCost;
    autoClickerPower = 1;
    autoClickerUpgradeCost = 200;
    document.getElementById('autoclicker-upgrade-cost').textContent = autoClickerUpgradeCost;
    if (typeof showNotification === "function") {
      showNotification(`Ascended! Base click power is now ${pointsPerClick}.`);
    }
    if (typeof saveGame === "function") saveGame();
    if (typeof saveAscension === "function") saveAscension();
  } else {
    if (typeof showNotification === "function") {
      showNotification(`You need ${ascensionRequirement} score to ascend.`);
    }
  }
});

// Save/load ascension data
function loadAscension() {
  const saved = JSON.parse(localStorage.getItem('clickerGameSave') || '{}');
  ascensionCount = saved.ascensionCount ?? 0;
  ascensionRequirement = saved.ascensionRequirement ?? 10000;
}

function saveAscension() {
  const saved = JSON.parse(localStorage.getItem('clickerGameSave') || '{}');
  saved.ascensionCount = ascensionCount;
  saved.ascensionRequirement = ascensionRequirement;
  localStorage.setItem('clickerGameSave', JSON.stringify(saved));
}

// Patch global save/load functions if they exist
if (typeof loadGame === "function") {
  const originalLoadGame = loadGame;
  window.loadGame = function() {
    originalLoadGame();
    loadAscension();
    document.getElementById('ascension-count').textContent = ascensionCount;  
    ascendBtn.textContent = `Ascend (Reset for bonus) - Requires ${ascensionRequirement} score`;
    };
}


if (typeof saveGame === "function") {
  const originalSaveGame = saveGame;
  window.saveGame = function() {
    originalSaveGame();
    saveAscension();
  };
}


// Save on unload
window.addEventListener('beforeunload', saveGame);
// Save on unload for ascension
window.addEventListener('beforeunload', saveAscension);




// still doesnt save ascensions
//maybe its because its saving itself before the ascension save function can run

